package ui;

import clases.ManejoDB;
import clases.Product;

import java.util.LinkedList;
import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/* Consultas: �Puedo colocar un return dentro de un try? O esto produciria que nunca se cierre?
		 * Tema lector de datos por teclado
		 * 
		 */
		
		ManejoDB db = new ManejoDB();
		db.conectar();
		//db.list();
		//db.nuevo("hongos", "C12H17N2O4P", 15, 45, true);
		//db.search(4);
		//db.erradicar(4);
		
		int opc = 0;
		Product p = new Product();
		Scanner leer = new Scanner(System.in);
		while (opc != 9) {
			
			menu();
			opc = leer.nextInt();
			Scanner otroLeer = new Scanner(System.in);
			switch(opc) {
			case 1:
				LinkedList<Product> productos = new LinkedList<>();
				productos = db.list();
				System.out.println("\nProduct list: ");
				System.out.println(productos);
				break;
			case 2:
				//Scanner otroLeer = new Scanner(System.in);
				System.out.println("Insert the id u looking for: ");
				p.setId(otroLeer.nextInt());
				p = db.search(p);
				System.out.println("Product u were looking for: ");
				System.out.println(p);
				break;
			case 3:
				/*
				 * String nombre; String desc; int cant; Double precio; boolean b;
				 */
				p = leerDatos(p);
				p = db.nuevo(p);
				System.out.println("New ID: ");
				System.out.println(p.getId());
				break;
			case 4:
				//Scanner otroLeer = new Scanner(System.in);
				System.out.println("Insert the id u looking to delete for: ");
				p.setId(otroLeer.nextInt());
				db.erradicar(p);
				System.out.println("Eliminacion correcta");
				break;
			case 5:
				//Scanner otroLeer = new Scanner(System.in);
				System.out.println("Insert the id u looking for: ");
				p.setId(otroLeer.nextInt());
				p = db.search(p);
				System.out.println("The product u r going to modify is: ");
				System.out.println(p);
				p = leerDatos(p);
				db.cambio(p);
				break;
			case 9:
				break;
			default:
				System.out.println("Meteme un numero valido hijueputa");
			}
			
		}
		
	}
	
	public static Product leerDatos(Product p) {
		Scanner leer = new Scanner(System.in);
		System.out.println("Insert the name: ");
		p.setName(leer.nextLine());
		System.out.println("Insert descr: ");
		p.setDescription(leer.nextLine());
		System.out.println("Insert quantity: ");
		p.setStock(leer.nextInt());
		System.out.println("Insert price: ");
		p.setPrice(leer.nextDouble());
		System.out.println("is shipphiable?");
		p.setShippingIncluded(leer.nextBoolean());
		leer.close();
		return p;
	}
	
	public static void menu() {
		System.out.println("\n\nDB Menu");
		System.out.println("1: List");
		System.out.println("2: Search");
		System.out.println("3: New");
		System.out.println("4: Delete");
		System.out.println("5: Update");
		System.out.println("9: Exit");
		System.out.println("Insert what u want to do: ");
	}

}
