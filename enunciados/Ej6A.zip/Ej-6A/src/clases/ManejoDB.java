package clases;

import java.sql.*;
import java.util.LinkedList;

public class ManejoDB {
	
	public void conectar(){
	try {
		Class.forName("con.mysql.cj.jdbc.Driver");	
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public LinkedList<Product> list() {
		Connection conn = null;
		LinkedList<Product> productos = new LinkedList<>();
		try {
			conn = 
				DriverManager.getConnection("jdbc:mysql://localhost/javamarket","root","root");
			
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select p.id, p.name, p.price from product p;");
			
			while(rs.next()) {
				Product p = new Product();
				
				p.setId(rs.getInt("id"));
				p.setName(rs.getString("name"));
				p.setPrice(rs.getDouble("price"));
				
				productos.add(p);
			}
			if(rs!=null) {rs.close();}
			if(stmt!=null) {stmt.close();}
			
			conn.close();
			
			}catch(SQLException ex) {
		System.out.println("SQLException: " +ex.getMessage());
		System.out.println("SQLState: " + ex.getSQLState());
		System.out.println("VendorError: " + ex.getErrorCode());
									}
		return productos;
	}
	
	public Product search(Product p) {
		Connection conn = null;
		try {
			conn = 
				DriverManager.getConnection("jdbc:mysql://localhost/javamarket","root","root");
			
			//Statement stmt = conn.createStatement();
			//ResultSet rs = stmt.executeQuery("select * from product p where p.id = ?;");
			// CAMBIAR ARRIBA PARA QUE ENVIE EL IDEN
			
			PreparedStatement stmt = conn.prepareStatement("select * from product p where p.id = ?;");
			stmt.setInt(1, p.getId());
			ResultSet rs = stmt.executeQuery();
			
			//rs.next();
			//Product p = new Product();
			if(rs.next()) {
			p.setId(rs.getInt("id")); 
			p.setName(rs.getString("name"));
			p.setPrice(rs.getDouble("price"));
			p.setDescription(rs.getString("description"));
			p.setStock(rs.getInt("stock"));
			p.setShippingIncluded(rs.getBoolean("shippingIncluded"));
			}
				
			if(rs!=null) {rs.close();}
			if(stmt!=null) {stmt.close();}
			
			conn.close();
			/*
			 * System.out.println("Producto: "); System.out.println(p);
			 * System.out.println(); System.out.println();
			 */
			
			}catch(SQLException ex) {
		System.out.println("SQLException: " +ex.getMessage());
		System.out.println("SQLState: " + ex.getSQLState());
		System.out.println("VendorError: " + ex.getErrorCode());
									}
		return p;
	}
	
	public Product nuevo(Product p) {
	  Connection conn = null; 
	  try { 
		  conn = DriverManager.getConnection("jdbc:mysql://localhost/javamarket","root","root");
	  
	  PreparedStatement pstmt = conn.prepareStatement(
			  "insert into product(name,description,price,stock,shippingIncluded) values (?,?,?,?,?)"); 
	  pstmt.setString (1, p.getName());
	  pstmt.setString (2, p.getDescription());
	  pstmt.setDouble (3, p.getPrice());
	  pstmt.setInt	  (4, p.getStock());
	  pstmt.setBoolean(5, p.isShippingIncluded());
	  
	  pstmt.executeUpdate();
	  
	  ResultSet keyResultSet = pstmt.getGeneratedKeys();
	  
	  if(keyResultSet!=null && keyResultSet.next()) {
			
		  p.setId(keyResultSet.getInt(1));
		  /*
		   * int id=keyResultSet.getInt(1); System.out.println("Nuevo Producto");
		   * System.out.println("ID: "+ id); System.out.println(); System.out.println();
		   */
	  }
	  
	  if(pstmt!=null) {pstmt.close();}
	  
	  conn.close();
	  
	  }catch(SQLException ex) { 
	  System.out.println("SQLException: "+ ex.getMessage()); 
	  System.out.println("SQLState: " + ex.getSQLState());
	  System.out.println("VendorError: " + ex.getErrorCode()); 
	  							} 
	  return p;
	  }

	public void erradicar(Product p) {
	
		Connection conn = null; try { conn =
		DriverManager.getConnection("jdbc:mysql://localhost/javamarket","root","root"
		);
				  
		PreparedStatement pstmt = conn.prepareStatement(
			"delete p from product p where p.id = ?");
		pstmt.setInt(1, p.getId());
				  
		pstmt.executeUpdate();
				  
		if(pstmt!=null) {pstmt.close();}
				  
		conn.close();
				  
		}catch(SQLException ex) { 
		System.out.println("SQLException: "+ ex.getMessage()); 
		System.out.println("SQLState: " + ex.getSQLState());
		System.out.println("VendorError: " + ex.getErrorCode()); 
				  			} 
	}
	
	public void cambio(Product p) {
		
		Connection conn = null; try { conn =
		DriverManager.getConnection("jdbc:mysql://localhost/javamarket","root","root");
				  
		PreparedStatement pstmt = conn.prepareStatement(
		"update product p set p.name = ?, p.description = ?, p.price = ?, p.stock = ?, p.shippingIncluded = ? where id = ?;"); 
		pstmt.setString (1, p.getName());
		pstmt.setString (2, p.getDescription());
		pstmt.setDouble (3, p.getPrice());
		pstmt.setInt	(4, p.getStock());
		pstmt.setBoolean(5, p.isShippingIncluded());
		pstmt.setInt	(6, p.getId());
				  
		pstmt.executeUpdate();
				  
		if(pstmt!=null) {pstmt.close();}
				  
		conn.close();
				  
		}catch(SQLException ex) { 
		System.out.println("SQLException: "+ ex.getMessage()); 
		System.out.println("SQLState: " + ex.getSQLState());
		System.out.println("VendorError: " + ex.getErrorCode()); 
				  				} 
	}

}
